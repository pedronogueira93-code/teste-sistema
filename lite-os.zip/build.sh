#!/usr/bin/env bash
# Lite OS - script de build da ISO (64 bits, Debian 13)
# Requer: Debian/Ubuntu com live-build e acesso a internet
#   sudo apt install live-build
#   sudo ./build.sh
set -euo pipefail

if [[ $EUID -ne 0 ]]; then
  echo "Execute como root: sudo ./build.sh" >&2
  exit 1
fi

cd "$(dirname "$0")"

lb clean --purge || true

lb config \
  --distribution trixie \
  --architectures amd64 \
  --archive-areas "main contrib non-free non-free-firmware" \
  --apt-recommends false \
  --binary-images iso-hybrid \
  --bootloaders "grub-efi,syslinux" \
  --debian-installer live \
  --chroot-squashfs-compression-type zstd \
  --iso-application "Lite OS" \
  --iso-publisher "Lite OS Project" \
  --iso-volume "LITE_OS" \
  --bootappend-live "boot=live components quiet splash nowatchdog transparent_hugepage=madvise username=lite hostname=liteos locales=pt_BR.UTF-8 keyboard-layouts=br timezone=America/Campo_Grande" \
  --memtest none

lb build 2>&1 | tee build.log

echo
echo "Pronto! ISO gerada:"
ls -lh ./*.iso
echo "Teste com: qemu-system-x86_64 -m 2G -enable-kvm -cdrom live-image-amd64.hybrid.iso"
