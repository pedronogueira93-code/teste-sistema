# Lite OS

Distribuição Linux 64 bits baseada em Debian 13, com Openbox + tint2, feita para
deixar o **Google Chrome o mais leve possível**. Gera uma ISO híbrida (BIOS + UEFI)
que roda em modo live e pode ser instalada.

## Como o Chrome fica leve

| Camada | O que foi feito |
|---|---|
| Launcher `chrome-lite` | Modo de pouca memória, no máximo 4 processos de aba, cache limitado (100 MB), recursos inúteis desligados (Translate, MediaRouter) |
| Políticas do Chrome | Sem execução em segundo plano, Memory Saver no modo máximo (abas inativas são suspensas), sem pré-carregamento de páginas, sem telemetria, sem corretor ortográfico |
| uBlock Origin Lite | Instalado à força pela política: bloquear anúncios reduz bastante a RAM por aba |
| Sistema | Sem compositor, desktop mínimo, zram (swap comprimido) com zstd, sysctl ajustado, `transparent_hugepage=madvise`, serviços inúteis desligados |
| earlyoom | Se faltar memória, encerra o Chrome antes de travar o desktop (nunca o Xorg ou o Openbox) |
| Aceleração | Mesa/Vulkan/VA-API instalados: o vídeo e a rolagem usam a GPU em vez da CPU |

O Chrome é baixado do site oficial da Google durante o build (`config/hooks/live/0200-chrome.hook.chroot`),
então a máquina que gera a ISO precisa de internet. Ele só existe para 64 bits.

> Uso pessoal: os termos da Google não permitem redistribuir o Chrome dentro de uma ISO
> publicada para outras pessoas. Se for distribuir o Lite OS, troque por Chromium
> (pacote `chromium` do Debian) ou faça o download do Chrome no primeiro boot.

## Como gerar a ISO

Em um Debian ou Ubuntu com internet:

```bash
sudo apt install live-build qemu-system-x86
sudo ./build.sh
```

Ou pelo GitHub: envie o projeto para um repositório, vá em Actions, escolha
"Build Lite OS ISO (64 bits)" e clique em Run workflow. A ISO aparece em Artifacts.

## Testar

```bash
qemu-system-x86_64 -m 2G -enable-kvm -cdrom live-image-amd64.hybrid.iso
```

Para gravar em pendrive: `sudo dd if=live-image-amd64.hybrid.iso of=/dev/sdX bs=4M status=progress`
(troque `/dev/sdX` pelo seu pendrive, com cuidado).

## Estrutura

| Caminho | Função |
|---|---|
| `build.sh` | Configura e gera a ISO |
| `config/package-lists/lite.list.chroot` | Pacotes incluídos |
| `config/hooks/live/0100-branding.hook.chroot` | Idioma, login automático, hora e serviços desligados |
| `config/hooks/live/0200-chrome.hook.chroot` | Instala o Chrome e o define como padrão |
| `config/includes.chroot/usr/local/bin/chrome-lite` | Launcher com as opções de economia |
| `config/includes.chroot/etc/opt/chrome/policies/managed/liteos.json` | Políticas do Chrome |
| `config/includes.chroot/etc/default/earlyoom` | Prioridade ao encerrar apps sem memória |
| `branding/` | Logo, papel de parede e ilustrações da interface |

## Personalizar

- Ajustar o Chrome: edite `chrome-lite` (flags) e `liteos.json` (políticas)
- Não quer o bloqueador de anúncios: apague `ExtensionInstallForcelist` em `liteos.json`
- Trocar apps: edite `lite.list.chroot` e o `menu.xml`
